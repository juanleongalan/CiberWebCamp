-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-12-2019 a las 03:48:26
-- Versión del servidor: 10.4.10-MariaDB
-- Versión de PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ciberwebcamp`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria_evento`
--

CREATE TABLE `categoria_evento` (
  `id_categoria` tinyint(10) NOT NULL,
  `cat_evento` varchar(50) NOT NULL,
  `icono` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `categoria_evento`
--

INSERT INTO `categoria_evento` (`id_categoria`, `cat_evento`, `icono`) VALUES
(1, 'Seminario', 'fa-university'),
(2, 'Conferencias', 'fa-comment'),
(3, 'Talleres', 'fa-code');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos`
--

CREATE TABLE `eventos` (
  `evento_id` tinyint(10) NOT NULL,
  `nombre_evento` varchar(60) NOT NULL,
  `fecha_evento` date NOT NULL,
  `hora_evento` time NOT NULL,
  `id_categoria_evento` tinyint(10) NOT NULL,
  `id_inv` tinyint(4) NOT NULL,
  `clave` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `eventos`
--

INSERT INTO `eventos` (`evento_id`, `nombre_evento`, `fecha_evento`, `hora_evento`, `id_categoria_evento`, `id_inv`, `clave`) VALUES
(2, 'Ataques DDOS', '2020-01-24', '10:00:00', 3, 5, 'taller_01'),
(3, 'MSF', '2020-01-24', '12:00:00', 3, 2, 'taller_02'),
(4, 'SQLInjection', '2020-01-24', '14:00:00', 3, 3, 'taller_03'),
(5, 'BurpSuite', '2020-01-24', '17:00:00', 3, 4, 'taller_04'),
(6, 'DFIR en Windows', '2020-01-24', '19:00:00', 3, 5, 'taller_05'),
(7, 'Explotacion de leaks de WhatsApp Web', '2020-01-24', '10:00:00', 2, 4, 'conf_01'),
(8, 'Analisis Forensis', '2020-01-24', '17:00:00', 2, 1, 'conf_02'),
(9, 'Seguridad en la Web', '2020-01-24', '19:00:00', 2, 2, 'conf_03'),
(10, 'Simulando ciberataques con Cymulate', '2020-01-24', '10:00:00', 1, 6, 'sem_01'),
(11, 'Radioescucha y SDR', '2020-01-25', '10:00:00', 3, 1, 'taller_06'),
(12, 'Jugando a los CTFs', '2020-01-25', '12:00:00', 3, 2, 'taller_07'),
(13, 'Desarrolla tu BadUSB con WiFi y almacenamiento', '2020-01-25', '14:00:00', 3, 3, 'taller_08'),
(14, 'Seguridad Wireless', '2020-01-25', '17:00:00', 3, 4, 'taller_09'),
(15, 'Linux Server', '2020-01-25', '19:00:00', 3, 5, 'taller_10'),
(16, 'Haching con PHP', '2020-01-25', '21:00:00', 3, 6, 'taller_11'),
(17, 'Caso Quebec DFIR', '2020-01-25', '10:00:00', 2, 6, 'conf_04'),
(18, 'Packet Wars: Journey to Scapy', '2020-01-25', '17:00:00', 2, 1, 'conf_05'),
(19, 'Introducción a la ingeniería inversa de Android Apps', '2020-01-25', '19:00:00', 2, 2, 'conf_06'),
(20, 'Inicio a la programacion', '2020-01-25', '10:00:00', 1, 3, 'sem_02'),
(21, 'La importancia de los Captcha', '2020-01-25', '17:00:00', 1, 5, 'sem_03'),
(22, 'Seguridad WPA3', '2020-01-26', '10:00:00', 3, 1, 'taller_12'),
(23, 'Creacion de API', '2020-01-26', '12:00:00', 3, 2, 'taller_13'),
(24, 'JavaScript de 0 a 100', '2020-01-26', '14:00:00', 3, 3, 'taller_14'),
(25, 'Hacking WordPress', '2020-01-26', '17:00:00', 3, 4, 'taller_15'),
(26, 'Carding', '2020-01-26', '19:00:00', 3, 5, 'taller_16'),
(27, 'Navega Seguro con una VPN', '2020-01-26', '10:00:00', 2, 6, 'conf_07'),
(28, 'Firewalls OpenSource', '2020-01-26', '17:00:00', 2, 2, 'conf_08'),
(29, 'Phishing, Pharming, Vishing, and Smishing', '2020-01-26', '19:00:00', 2, 3, 'conf_09'),
(30, 'Creando una Botnet en una mañana', '2020-01-26', '10:00:00', 1, 4, 'sem_04'),
(31, 'Creando un Portal Cautivo en una tarde', '2020-01-26', '17:00:00', 1, 1, 'sem_05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `invitados`
--

CREATE TABLE `invitados` (
  `invitado_id` tinyint(10) NOT NULL,
  `nombre_invitado` varchar(30) NOT NULL,
  `apellido_invitado` varchar(30) NOT NULL,
  `descripcion` text NOT NULL,
  `url_imagen` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `invitados`
--

INSERT INTO `invitados` (`invitado_id`, `nombre_invitado`, `apellido_invitado`, `descripcion`, `url_imagen`) VALUES
(1, 'Rafael', 'Bautista', 'Excepturi adipisci nisi perspiciatis, quasi recusandae cupiditate laborum itaque dolores mollitia sapiente eveniet, hic qui est vitae animi aspernatur voluptatum ipsa ipsam', 'invitado1.jpg'),
(2, 'Sara', 'Herrera', 'Excepturi adipisci nisi perspiciatis, quasi recusandae cupiditate laborum itaque dolores mollitia sapiente eveniet, hic qui est vitae animi aspernatur voluptatum ipsa ipsam', 'invitado2.jpg'),
(3, 'Gregorio', 'Sanchez', 'Excepturi adipisci nisi perspiciatis, quasi recusandae cupiditate laborum itaque dolores mollitia sapiente eveniet, hic qui est vitae animi aspernatur voluptatum ipsa ipsam', 'invitado3.jpg'),
(4, 'Maria Jose', 'Rivera', 'Excepturi adipisci nisi perspiciatis, quasi recusandae cupiditate laborum itaque dolores mollitia sapiente eveniet, hic qui est vitae animi aspernatur voluptatum ipsa ipsam', 'invitado4.jpg'),
(5, 'Aaron', 'Garcia', 'Excepturi adipisci nisi perspiciatis, quasi recusandae cupiditate laborum itaque dolores mollitia sapiente eveniet, hic qui est vitae animi aspernatur voluptatum ipsa ipsam', 'invitado5.jpg'),
(6, 'Susana ', 'Sanchez', 'Excepturi adipisci nisi perspiciatis, quasi recusandae cupiditate laborum itaque dolores mollitia sapiente eveniet, hic qui est vitae animi aspernatur voluptatum ipsa ipsam', 'invitado6.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `regalos`
--

CREATE TABLE `regalos` (
  `ID_regalo` int(11) NOT NULL,
  `nombre_regalo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `regalos`
--

INSERT INTO `regalos` (`ID_regalo`, `nombre_regalo`) VALUES
(1, 'Pegatina'),
(2, 'Llavero'),
(3, 'Gorra');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registrados`
--

CREATE TABLE `registrados` (
  `ID_Registrado` bigint(20) UNSIGNED NOT NULL,
  `nombre_registrado` varchar(50) NOT NULL,
  `apellido_registrado` varchar(50) NOT NULL,
  `email_registrado` varchar(100) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `pases_articulos` longtext NOT NULL,
  `talleres_registrados` longtext NOT NULL,
  `regalo` int(11) NOT NULL,
  `total_pagado` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `registrados`
--

INSERT INTO `registrados` (`ID_Registrado`, `nombre_registrado`, `apellido_registrado`, `email_registrado`, `fecha_registro`, `pases_articulos`, `talleres_registrados`, `regalo`, `total_pagado`) VALUES
(4, 'juan', 'leon', 'juanleon@hotmail.com', '2019-12-17 06:55:33', '{\"un_dia\":1,\"camisas\":1,\"etiquetas\":1}', '{\"evento\":[\"taller_05\",\"conf_02\",\"conf_03\"]}', 1, '54.74'),
(5, 'pablo', 'peña', 'peña@gmail.com', '2019-12-17 06:56:38', '{\"pase_2dias\":1,\"camisas\":1,\"etiquetas\":1}', '{\"evento\":[\"sem_01\",\"conf_05\"]}', 1, '69.74000000000001'),
(6, 'juan', 'peña', 'peña@gmail.com', '2019-12-17 08:34:43', '{\"pase_2dias\":1,\"camisas\":1,\"etiquetas\":1}', '{\"evento\":[\"conf_01\",\"conf_02\",\"taller_11\",\"conf_04\"]}', 1, '69.74000000000001'),
(7, 'juan', 'leon', 'juanleon@hotmail.com', '2019-12-18 01:07:43', '{\"pase_2dias\":1,\"camisas\":3,\"etiquetas\":2}', '{\"evento\":[\"taller_01\",\"taller_02\",\"taller_03\",\"conf_01\",\"conf_02\",\"taller_09\",\"conf_04\",\"conf_05\",\"sem_03\"]}', 2, '111.22'),
(8, 'juan', 'leon', 'juanleon@hotmail.com', '2019-12-18 01:19:06', '{\"pase_2dias\":1,\"camisas\":1,\"etiquetas\":1}', '[]', 1, '69.74000000000001'),
(9, 'juan', 'leon', 'juanleon@hotmail.com', '2019-12-18 02:23:37', '{\"pase_2dias\":1}', '[]', 1, '45');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria_evento`
--
ALTER TABLE `categoria_evento`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`evento_id`),
  ADD KEY `id_categoria_evento` (`id_categoria_evento`),
  ADD KEY `id_inv` (`id_inv`);

--
-- Indices de la tabla `invitados`
--
ALTER TABLE `invitados`
  ADD PRIMARY KEY (`invitado_id`);

--
-- Indices de la tabla `regalos`
--
ALTER TABLE `regalos`
  ADD PRIMARY KEY (`ID_regalo`);

--
-- Indices de la tabla `registrados`
--
ALTER TABLE `registrados`
  ADD PRIMARY KEY (`ID_Registrado`),
  ADD KEY `regalo` (`regalo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categoria_evento`
--
ALTER TABLE `categoria_evento`
  MODIFY `id_categoria` tinyint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `eventos`
--
ALTER TABLE `eventos`
  MODIFY `evento_id` tinyint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `invitados`
--
ALTER TABLE `invitados`
  MODIFY `invitado_id` tinyint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `regalos`
--
ALTER TABLE `regalos`
  MODIFY `ID_regalo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `registrados`
--
ALTER TABLE `registrados`
  MODIFY `ID_Registrado` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `eventos`
--
ALTER TABLE `eventos`
  ADD CONSTRAINT `eventos_ibfk_1` FOREIGN KEY (`id_categoria_evento`) REFERENCES `categoria_evento` (`id_categoria`),
  ADD CONSTRAINT `eventos_ibfk_2` FOREIGN KEY (`id_inv`) REFERENCES `invitados` (`invitado_id`);

--
-- Filtros para la tabla `registrados`
--
ALTER TABLE `registrados`
  ADD CONSTRAINT `registrados_ibfk_1` FOREIGN KEY (`regalo`) REFERENCES `regalos` (`ID_regalo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
